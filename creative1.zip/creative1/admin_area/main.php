<html>
<head><link rel="stylesheet" type="text/css" href="table.css"></head>

<body>
<ul class="todolist">
  <li class="task">
    <input type="checkbox" id="task1" />
    <label for="task1">Task 1</label>
  </li>
  <li class="task">
    <input type="checkbox" id="task2" checked />
    <label for="task2">Task 2</label>
  </li>
  <li class="task">
    <input type="checkbox" id="task3" />
    <label for="task3">Task 3</label>
  </li>
  <li class="task">
    <input type="checkbox" id="task4" />
    <label for="task4">Task 4</label>
  </li>
</ul>
</body>
<style>

</style>