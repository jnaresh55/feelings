<footer>
		

		<!--// CopyRight \\-->
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<div class="political-copyright">
                    	<p><span>&copy; 2018 Creative Electronics. All Rights Reserved.</a></span></p>
						<ul class="political-team-social">
							<li><a href="https://www.facebook.com/" class="fa fa-facebook-square"></a></li>
							<li><a href="https://www.twitter.com" class="fa fa-twitter-square"></a></li>
							<li><a href="https://www.gmail.com" class="fa fa-google-plus-square"></a></li>
							<li><a href="https://www.youtube.com" class="fa fa-youtube-square"></a></li>
						</ul>
						
					</div>
				</div>
			</div>
		</div>		
		<!--// CopyRight \\-->

	</footer>
	<!--// Footer \\-->

	<div class="clearfix"></div>

	</div>
	<!--// Main Wrapper \\-->

	<!-- Modal -->
	<div class="modal fade searchmodal" id="searchmodal" tabindex="-1" role="dialog">
		<div class="modal-dialog" role="document">
			<div class="modal-body">
				<a href="#" class="political-close-btn" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></a>
				<form>
					<input type="text" value="Type Your Keyword" onblur="if(this.value == '') { this.value ='Type Your Keyword'; }" onfocus="if(this.value =='Type Your Keyword') { this.value = ''; }">
					<input type="submit" value="">
					<i class="fa fa-search"></i>
				</form>
			</div>
		</div>
	</div>


	 <!-- jQuery (necessary for JavaScript plugins) -->
	 <script type="text/javascript" src="script/jquery.js"></script>
	 <script type="text/javascript" src="script/bootstrap.min.js"></script>
	 <script type="text/javascript" src="script/slick.slider.min.js"></script>
	 <script type="text/javascript" src="script/fancybox.pack.js"></script>
	 <script type="text/javascript" src="script/isotope.min.js"></script>
	 <script type="text/javascript" src="script/progressbar.js"></script>
	 <script type="text/javascript" src="script/jplayer.functions.js"></script>
	 <script type="text/javascript" src="script/jquery.jplayer.js"></script>
	 <script type="text/javascript" src="script/jplayer.playlist.js"></script>
	 <script type="text/javascript" src="script/numscroller.js"></script>
	 <script type="text/javascript" src="script/circle-chart.js"></script>
	 <script type="text/javascript" src="build/mediaelement-and-player.min.js"></script>
	 <script type="text/javascript" src="https://maps.googleapis.com/maps/api/js"></script>
	 <script type="text/javascript" src="script/functions.js"></script>
	 
	</body>

</html>